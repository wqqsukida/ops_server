# -*- coding: UTF-8 -*-

TEST = True

PLUGIN_ITEMS = {
    "basic": "src.plugins.basic.Basic",
    "board": "src.plugins.board.Board",
}