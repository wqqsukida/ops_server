# /usr/bin/env python
# -*- coding:utf-8 -*-
# Author  : wuyifei
# Data    : 12/3/18 9:43 AM
# FileName: progress.py
import time
'''
res = {

    "name": "test.py",

    "path": "/tmp/test.py",

    "args": "-t 10 -d 4",

    "status": 0,

    "msg": "some desc",

    "elapsed": 40

}
'''

def get_res():
    res = {
        "name": "test.py",
        "path": "/tmp/test.py",
        "args": "-t 10 -d 4",
        "status": 0,
        "msg": "some desc",
        "elapsed": 40
               }

    return res